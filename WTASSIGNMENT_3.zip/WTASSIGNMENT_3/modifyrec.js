var myApp = angular.module('modifyrecord', []);
myApp.controller('MyController', function ($scope) {
    $scope.cops=[{"name":"Jane","age":34,"height":'5.6',"act":'ACT2002',"date":'12-05-2020',"gender":"Male","weight":60,"crime":'kidnap',"firno":145,"stataddr":'lbnagar'},{"name":"John","age":42,"height":'5.4',"act":'ACT2007',"date":'22-03-2019',"gender":"Male","weight":63 ,"crime":'theft',"firno":230,"stataddr":'Ameerpet'}]
    $scope.submit= function() {
        $scope.cops.forEach(function(cop) {
            if(cop.firno==parseInt($scope.search))
                {
                    $scope.name=cop.name;
                    $scope.age=cop.age;
                    $scope.height=cop.height;
                    $scope.act=cop.act;
                    $scope.dt=(cop.date).split('-');
                    $scope.date=new Date($scope.dt[2],($scope.dt[1])-1,$scope.dt[0]);
                    if(cop.gender=="Male")
                        {
                            $scope.gender1=true;
                        }
                    else{
                        $scope.gender2=true;
                    }
                    $scope.weight=cop.weight;
                    $scope.crime=cop.crime;
                    $scope.firno=cop.firno;
                    $scope.stationaddr=cop.stataddr;
                }
    });
  };
    $scope.modify=function(){
         $scope.cops.forEach(function(cop) {
            if(cop.firno==parseInt($scope.search))
                {

                    cop.name=$scope.name;
                    cop.age=$scope.age;
                    cop.height=$scope.height;
                    cop.act=$scope.act;
                    cop.date=$scope.date;
            
                    cop.weight=$scope.weight;
                    cop.crime=$scope.crime;
                    cop.firno=$scope.firno;
                    cop.stataddr=$scope.stationaddr;
                   
                        if($scope.g1=="Male")
                            {
                                cop.gender="Male";
                            }
                        else{
                            cop.gender="Female";
                        }
                    

                }
    });
        
    }
});

