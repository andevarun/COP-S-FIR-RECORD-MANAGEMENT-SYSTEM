import java.io.*;
import java.text.SimpleDateFormat;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*; 
import java.util.*;
public class Insert extends HttpServlet {

  
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    { 
        try { 
				Class.forName("oracle.jdbc.driver.OracleDriver");    
				Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","it19737121","vasavi");  
				PreparedStatement st = con.prepareStatement("insert into copinsert values(?, ?, ?, ?, ?,?,?,?,?,?)"); 
				st.setString(1,request.getParameter("copname"));
				st.setInt(2, Integer.valueOf(request.getParameter("copage")));
				st.setFloat(3, Float.valueOf(request.getParameter("copheight")));
				st.setString(4, request.getParameter("copact"));				
				st.setString(5, request.getParameter("copdate")); 
				st.setString(6,request.getParameter("copgender"));
				st.setInt(7,Integer.valueOf(request.getParameter("copweight")));
				st.setString(8,request.getParameter("copcrime"));
				st.setInt(9,Integer.valueOf(request.getParameter("copfirno")));				
				st.setString(10,request.getParameter("copstationaddr")); 				
				st.executeUpdate();
				st.close();   
				con.close();   
				response.sendRedirect("a2addrecord.html");
				

        } 
        catch (Exception e) { 
            e.printStackTrace(); 
        } 
    } 
} 