var myApp = angular.module('delrecord', []);
myApp.controller('MyController', function ($scope) {
    $scope.cops=[{"name":"Jane","age":34,"height":'5.6',"act":'ACT2002',"date":'12-05-2020',"gender":"Male","weight":60,"crime":'kidnap',"firno":145,"stataddr":'lbnagar'},{"name":"John","age":42,"height":'5.4',"act":'ACT2007',"date":'22-03-2019',"gender":"Male","weight":63 ,"crime":'theft',"firno":230,"stataddr":'Ameerpet'}]
    $scope.delete= function() {
        $scope.cops.forEach(function(cop) {
            if(cop.firno==parseInt($scope.search))
                {
                    cop.name="";
                    cop.age="";
                    cop.height="";
                    cop.act="";
                    cop.date="";
                    cop.gender="";
                    cop.weight="";
                    cop.crime="";
                    cop.firno="";
                    cop.stataddr="";
                }
    });
  };
});