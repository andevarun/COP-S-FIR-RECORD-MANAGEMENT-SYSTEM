var myApp = angular.module('addrecord',[]);
myApp.controller('MyController', function($scope) {
 $scope.cop = {} 
});
