var myApp = angular.module('viewrecord', []);
myApp.controller('MyController', function ($scope) {
    $scope.cops=[{"name":'Jane',"age":34,"height":'5.6',"act":'ACT2002',"date":'12-May-2020',"gender":'male',"weight":'60 kg',"crime":'kidnap',"firno":145,"stataddr":'lbnagar'},{"name":'John',"age":42,"height":'5.4',"act":'ACT2007',"date":'22-March-2019',"gender":'male',"weight":'63 kg',"crime":'theft',"firno":230,"stataddr":'Ameerpet'}]
});
